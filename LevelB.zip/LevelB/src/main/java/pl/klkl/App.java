package pl.klkl;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void min( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
